// do while loops
let i = 5;

do{
  console.log('val of i is: ', i);
  i++;
} while(i < 5);

