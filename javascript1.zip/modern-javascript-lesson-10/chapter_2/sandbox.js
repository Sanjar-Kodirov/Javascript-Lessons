// common string methods

let email = 'mario@thenetninja.co.uk';

//let result = email.lastIndexOf('n');

//let result = email.slice(0,5);

//let result = email.substr(5,12);

//let result = email.replace('m', 'w');

let result = email.replace('n', 'w');

console.log(result);

