// function declaration
function greet(){
  console.log('hello there');
}

// function expression
const speak = function(){
  console.log('good day!');
};

// greet();
// greet();

speak();