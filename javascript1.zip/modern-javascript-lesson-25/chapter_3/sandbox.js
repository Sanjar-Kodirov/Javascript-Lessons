// Logical NOT
const user = false;

if(!user){
  // do something
  console.log('you must be logged in to continue');
}

console.log(!true);
console.log(!false);